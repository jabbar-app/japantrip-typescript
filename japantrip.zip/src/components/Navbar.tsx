'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ToggleTheme } from '@/components/ToggleTheme'

const Header = () => {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const tokenExists = document.cookie.includes('token=')
    const storedUser = localStorage.getItem('user')

    if (tokenExists && storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser)
        setUser(parsedUser)
      } catch (err: any) {
        console.log(err.message)
        console.error('Failed to parse user from localStorage')
      }
    } else {
      // Jika tidak ada token, hapus localStorage user
      localStorage.removeItem('user')
      setUser(null)
    }
  }, [])

  return (
    <header className="w-full px-4 py-3 border-b bg-background shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link href="/" className="text-lg font-bold text-primary">
          JapanTrip
        </Link>

        <div className="flex items-center gap-3">
          <ToggleTheme />
          {user ? (
            <span className="text-sm text-muted-foreground">Hi, {user.name}</span>
          ) : (
            <>
              <Link href="/login">
                <Button variant="outline">Login</Button>
              </Link>
              <Link href="/register">
                <Button>Register</Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}

export default Header
